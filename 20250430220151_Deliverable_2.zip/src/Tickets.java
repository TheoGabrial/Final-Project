import java.util.Comparator;
import java.util.Objects;

public abstract class Tickets implements Comparator {
    String name;
    String movie;
    int time;

    public Tickets() {

    }

    public Tickets(String name, String movie, int time) {
        this.name = name;
        this.movie = movie;
        this.time = time;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tickets tickets = (Tickets) o;
        return time == tickets.time && Objects.equals(name, tickets.name) && Objects.equals(movie, tickets.movie);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, movie, time);
    }

    @Override
    public String toString() {
        return "tickets{" +
                "name='" + name + '\'' +
                ", movie='" + movie + '\'' +
                ", time=" + time +
                '}';
    }

    public Tickets pickMovie(Tickets tickets) {

    }

    @Override
    public int compare(Object o1, Object o2) {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }
}


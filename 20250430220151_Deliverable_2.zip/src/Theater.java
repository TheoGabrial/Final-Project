import java.util.Objects;
import java.util.Set;

public abstract class Theater extends Tickets{
    int seat;
    int theater;

    public Theater() {

    }

    public Theater(String name, String movie, int time, int seat, int theater) {
        super(name, movie, time);
        this.seat = seat;
        this.theater = theater;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Theater theater1 = (Theater) o;
        return seat == theater1.seat && theater == theater1.theater;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), seat, theater);
    }

    @Override
    public String toString() {
        return "Theater{" +
                "seat=" + seat +
                ", theater=" + theater +
                ", name='" + name + '\'' +
                ", movie='" + movie + '\'' +
                ", time=" + time +
                '}';
    }

    public void checkSeat(Set<Integer> seats) {

    }

    public int getSeat() {
        return seat;
    }

    public void setSeat(int seat) {
        this.seat = seat;
    }

    public int getTheater() {
        return theater;
    }

    public void setTheater(int theater) {
        this.theater = theater;
    }
}

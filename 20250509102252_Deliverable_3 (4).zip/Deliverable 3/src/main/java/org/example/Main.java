package org.example;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        User customer = new Customer("Theo");
        customer.showUserType();

        List<Movie> movies = new ArrayList<>();
        movies.add(new RegularMovie("Inception", 148));
        movies.add(new VipMovie("Minecraft", 169));
        movies.add(new RegularMovie("Avengers", 106));

        movies.get(0).bookSeat(1);
        movies.get(1).bookSeat(2);

        BookingManager.saveBookings(movies, "bookings.txt");

        List<String> bookings = BookingManager.loadBookings("bookings.txt");
        System.out.println("Loaded bookings:");
        for (String b : bookings) {
            System.out.println(b);
        }

        Collections.sort(movies);
        System.out.println("Sorted by duration:");
        for (Movie m : movies) {
            System.out.println(m.getTitle() + " (" + m.getDuration() + " mins)");
        }

        movies.sort(new MovieTitleComparator());
        System.out.println("Sorted by title:");
        for (Movie m : movies) {
            System.out.println(m.getTitle());
        }
    }
}

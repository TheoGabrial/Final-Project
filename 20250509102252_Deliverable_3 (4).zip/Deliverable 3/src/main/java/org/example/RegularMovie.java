package org.example;

public class RegularMovie extends Movie {
    public RegularMovie(String title, int duration) {
        super(title, duration);
    }

    @Override
    public double getPrice() {
        return 13.0;
    }
}

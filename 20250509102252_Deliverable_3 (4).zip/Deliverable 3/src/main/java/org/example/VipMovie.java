package org.example;

public class VipMovie extends Movie {
    public VipMovie(String title, int duration) {
        super(title, duration);
    }

    @Override
    public double getPrice() {
        return 25.0;
    }
}

package org.example;
import java.util.HashSet;
import java.util.Set;

public abstract class Movie implements Bookable, Comparable<Movie> {
    protected String title;
    protected int duration;
    protected Set<Integer> bookedSeats = new HashSet<>();

    public Movie(String title, int duration) {
        this.title = title;
        this.duration = duration;
    }

    public abstract double getPrice();

    public String getTitle() {
        return title;
    }

    public int getDuration() {
        return duration;
    }

    public Set<Integer> getBookedSeats() {
        return bookedSeats;
    }

    /**
     * books a seat
     * @param seatNumber seat number
     */
    @Override
    public void bookSeat(int seatNumber) {
        if (!bookedSeats.contains(seatNumber)) {
            bookedSeats.add(seatNumber);
            System.out.println("Seat " + seatNumber + " booked for " + title);
        } else {
            System.out.println("Seat already booked.");
        }
    }

    @Override
    public int compareTo(Movie other) {
        return Integer.compare(this.duration, other.duration);
    }
}

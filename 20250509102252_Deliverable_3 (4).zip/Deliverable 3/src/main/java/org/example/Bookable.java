package org.example;

public interface Bookable {
    void bookSeat(int seatNumber);
}

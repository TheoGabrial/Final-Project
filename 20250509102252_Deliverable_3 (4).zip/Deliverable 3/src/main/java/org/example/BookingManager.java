package org.example;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class BookingManager {

    /**
     * saves booked seats to file
     * @param movies movies
     * @param filename file
     */
    public static void saveBookings(List<Movie> movies, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Movie movie : movies) {
                for (int seat : movie.getBookedSeats()) {
                    writer.write(movie.getTitle() + "," + seat);
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            System.err.println("Error writing file: " + e.getMessage());
        }
    }

    /**
     * puts moves in file into a stringList
     * @param filename file
     * @return stringList of movies
     */
    public static List<String> loadBookings(String filename) {
        List<String> bookings = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                bookings.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return bookings;
    }
}

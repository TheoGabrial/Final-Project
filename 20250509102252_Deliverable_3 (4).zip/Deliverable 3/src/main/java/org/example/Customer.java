package org.example;

public class Customer extends User {
    public Customer(String name) {
        super(name);
    }

    /**
     * prints customer
     */
    @Override
    public void showUserType() {
        System.out.println("Customer: " + name);
    }
}

package org.example;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MovieTest {

    @Test
    public void testBookingSeat() {
        Movie movie = new RegularMovie("Test Movie", 120);
        movie.bookSeat(5);
        assertTrue(movie.getBookedSeats().contains(5));
    }

    @Test
    public void testPrice() {
        Movie imax = new VipMovie("VIP Movie", 140);
        assertEquals(25.0, imax.getPrice(), 0.01);
    }

    @Test
    public void testComparable() {
        Movie m1 = new RegularMovie("Short", 90);
        Movie m2 = new RegularMovie("Long", 150);
        assertTrue(m1.compareTo(m2) < 0);
    }
}
